﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AppBoteco
{
    public partial class FrmVenda : Form
    {
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\AppBoteco\\AppBoteco\\DbBoteco.mdf;Integrated Security=True");
        
        public FrmVenda()
        {
            InitializeComponent();
            CarregaCbxCliente();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        public void CarregaCbxCliente()
        {
            con.Open();
            String cli = "SELECT Id, nome FROM Cliente";   // cria a query que selciona o id e nome da tabela cliente
            SqlCommand cmd = new SqlCommand(cli, con); // preparando o comando que vai pro banco
            
            cmd.CommandType = CommandType.Text;  // 
            SqlDataAdapter da = new SqlDataAdapter(cli, con);  //
            DataSet ds = new DataSet();  // ponte que vai comunicar com o banco
            da.Fill(ds, "cliente");   //preenche uma tabela virtual chamada cliente
            cbxCliente.ValueMember = "Id"; //  valores que vao pro banco
            cbxCliente.DisplayMember = "nome";//   moostro o nome 
            cbxCliente.DataSource = ds.Tables["cliente"];  //   a origem dos dados sera o "cliente"
            con.Close();
        }

    }
}
